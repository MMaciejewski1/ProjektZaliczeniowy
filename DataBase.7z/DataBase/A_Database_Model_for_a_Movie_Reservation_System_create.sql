-- Created by Vertabelo (http://vertabelo.com)
-- Last modification date: 2017-04-12 15:03:05.368

-- tables
-- Table: auditorium
CREATE TABLE "auditorium" (
    "id" int  NOT NULL,
    "name" varchar(32)  NOT NULL,
    "seats_no" int  NOT NULL,
    CONSTRAINT "auditorium_pk" PRIMARY KEY ("id")
);

-- Table: movie
CREATE TABLE "movie" (
    "id" int  NOT NULL,
    "title" varchar(256)  NOT NULL,
    "director" varchar(256)  NULL,
    "cast" varchar(1024)  NULL,
    "description" text  NULL,
    "duration_min" int  NULL,
    CONSTRAINT "movie_pk" PRIMARY KEY ("id")
);

-- Table: reservation
CREATE TABLE "reservation" (
    "id" int  NOT NULL,
    "screening_id" int  NOT NULL,
    "user_reserved_id" int  NULL,
    "reservation_contact" varchar(1024)  NOT NULL,
    "reserved" bool  NULL,
    "user_paid_id" int  NULL,
    "paid" bool  NULL,
    "active" bool  NOT NULL,
    CONSTRAINT "reservation_pk" PRIMARY KEY ("id")
);

-- Table: screening
CREATE TABLE "screening" (
    "id" int  NOT NULL,
    "movie_id" int  NOT NULL,
    "auditorium_id" int  NOT NULL,
    "screening_start" timestamp  NOT NULL,
    CONSTRAINT "Projection_ak_1" UNIQUE ("auditorium_id", "screening_start") NOT DEFERRABLE  INITIALLY IMMEDIATE,
    CONSTRAINT "screening_pk" PRIMARY KEY ("id")
);

-- Table: seat
CREATE TABLE "seat" (
    "id" int  NOT NULL,
    "row" int  NOT NULL,
    "number" int  NOT NULL,
    "auditorium_id" int  NOT NULL,
    CONSTRAINT "seat_pk" PRIMARY KEY ("id")
);

-- Table: seat_reserved
CREATE TABLE "seat_reserved" (
    "id" int  NOT NULL,
    "seat_id" int  NOT NULL,
    "reservation_id" int  NOT NULL,
    "screening_id" int  NOT NULL,
    CONSTRAINT "seat_reserved_pk" PRIMARY KEY ("id")
);

-- Table: user
CREATE TABLE "user" (
    "id" int  NOT NULL,
    "username" varchar(32)  NOT NULL,
    "password" varchar(100)  NOT NULL,
    "position" varchar(45)  NOT NULL,
    CONSTRAINT "user_pk" PRIMARY KEY ("id")
);

-- foreign keys
-- Reference: Projection_Movie (table: screening)
ALTER TABLE "screening" ADD CONSTRAINT "Projection_Movie"
    FOREIGN KEY ("movie_id")
    REFERENCES "movie" ("id")  
    NOT DEFERRABLE 
    INITIALLY IMMEDIATE
;

-- Reference: Projection_Room (table: screening)
ALTER TABLE "screening" ADD CONSTRAINT "Projection_Room"
    FOREIGN KEY ("auditorium_id")
    REFERENCES "auditorium" ("id")  
    NOT DEFERRABLE 
    INITIALLY IMMEDIATE
;

-- Reference: Reservation_Projection (table: reservation)
ALTER TABLE "reservation" ADD CONSTRAINT "Reservation_Projection"
    FOREIGN KEY ("screening_id")
    REFERENCES "screening" ("id")  
    NOT DEFERRABLE 
    INITIALLY IMMEDIATE
;

-- Reference: Reservation_paid_Employee (table: reservation)
ALTER TABLE "reservation" ADD CONSTRAINT "Reservation_paid_Employee"
    FOREIGN KEY ("user_paid_id")
    REFERENCES "user" ("id")  
    NOT DEFERRABLE 
    INITIALLY IMMEDIATE
;

-- Reference: Reservation_reserving_employee (table: reservation)
ALTER TABLE "reservation" ADD CONSTRAINT "Reservation_reserving_employee"
    FOREIGN KEY ("user_reserved_id")
    REFERENCES "user" ("id")  
    NOT DEFERRABLE 
    INITIALLY IMMEDIATE
;

-- Reference: Seat_Room (table: seat)
ALTER TABLE "seat" ADD CONSTRAINT "Seat_Room"
    FOREIGN KEY ("auditorium_id")
    REFERENCES "auditorium" ("id")  
    NOT DEFERRABLE 
    INITIALLY IMMEDIATE
;

-- Reference: Seat_reserved_Reservation_projection (table: seat_reserved)
ALTER TABLE "seat_reserved" ADD CONSTRAINT "Seat_reserved_Reservation_projection"
    FOREIGN KEY ("screening_id")
    REFERENCES "screening" ("id")  
    NOT DEFERRABLE 
    INITIALLY IMMEDIATE
;

-- Reference: Seat_reserved_Reservation_reservation (table: seat_reserved)
ALTER TABLE "seat_reserved" ADD CONSTRAINT "Seat_reserved_Reservation_reservation"
    FOREIGN KEY ("reservation_id")
    REFERENCES "reservation" ("id")  
    NOT DEFERRABLE 
    INITIALLY IMMEDIATE
;

-- Reference: Seat_reserved_Seat (table: seat_reserved)
ALTER TABLE "seat_reserved" ADD CONSTRAINT "Seat_reserved_Seat"
    FOREIGN KEY ("seat_id")
    REFERENCES "seat" ("id")  
    NOT DEFERRABLE 
    INITIALLY IMMEDIATE
;

-- End of file.

